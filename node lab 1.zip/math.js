function square(number){
    return number * number;
}
module.exports = {square};