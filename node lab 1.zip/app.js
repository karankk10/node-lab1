const math = require("./math");
const myEmitter = require("./emitter");

const result = math.square(8);
console.log(`Square is ${result}`);


myEmitter.emit("customEvent");
