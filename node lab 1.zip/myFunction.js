exports.myFunction = () => {

};

exports.myVariable = 'Hello, Node.js';

module.exports = {
    myFunction: ()=> {

    },
    myVariable: 'Hello, Node.js',
};
